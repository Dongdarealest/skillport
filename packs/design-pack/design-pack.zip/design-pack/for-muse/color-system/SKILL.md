# Color System

Most interfaces fail on color because they have too much of it, spread everywhere.

## Method

1. Start with neutrals tinted toward one hue, warm or cool. Pure gray looks dead next to real content.
2. Pick one accent. It appears on the primary action, the active state, and almost nothing else.
3. Richness goes into content: photography, charts, the product itself. Chrome stays quiet.
4. Define text colors by role, not by taste: primary, secondary, faint. Three is enough.
5. Check every pairing for contrast before shipping. Beauty that cannot be read is decoration.

## Output

The palette as named tokens with hex values, plus one line per token stating where it is allowed to appear.
