---
name: secrets-out
description: Scrubs credentials, tokens, personal data and private paths out of text and files before they are pasted into an AI chat, committed to a repo or sent to anyone. Use when the user is about to share code, logs, configs or screenshots outside their own machine.
license: MIT
---

# Secrets Out

Treat anything pasted into a chat, committed to a repo or attached to a message as published. It may be logged, indexed, forwarded or trained on. You cannot unpaste. So the scrub happens before sharing, every time, as a deliberate pass, not a hopeful glance.

## What counts as a secret

- API keys, access tokens, session cookies and authorization headers
- Passwords, including the ones inside connection strings and URLs
- Private keys, certificates and the full contents of `.env` files
- Personal data: email addresses, phone numbers, home addresses, ID numbers, client and patient names
- Private paths and names: your home directory path gives away your username, internal hostnames and admin URLs map someone else's network
- Screenshots and logs, which carry all of the above while looking harmless

## Method

1. **Search before you share.** Run a search over the exact text or files you are about to send. Useful patterns: `sk-`, `AKIA`, `Bearer `, `password`, `token`, `secret`, `PRIVATE KEY`, `@` for stray email addresses. Read every hit in context.
2. **Replace, do not just delete.** Swap each real value for a labelled placeholder that keeps the shape: `API_KEY_HERE`, `user@example.com`, `postgres://user:password@host/db` becomes `postgres://USER:PASSWORD@HOST/DB`. The AI still understands the structure, and nothing real leaves the machine.
3. **Keep the mapping private, if at all.** If you must restore real values later, keep the mapping in a local note that is never part of what you share. Most of the time you do not need it: retype the real value yourself at the end.
4. **Check history, not just the file.** In a repo, a secret removed in the latest commit still sits in every earlier commit and every clone. Search the history before pushing anything public.
5. **Rotate what already leaked.** If a real key has already been pasted or pushed, redaction is not a fix. Issue a new key and revoke the old one. That is the only step that actually closes the hole.

## Habits that prevent the problem

- Keep secrets in environment variables or a local `.env` file that is listed in `.gitignore` from the first commit, never in code, skills or notes.
- Give the AI the shape of the data, not the data: sample rows with fake names teach it everything real rows would.
- Make the scrub the last step before paste or commit, the way you check a pocket before laundry.

## Output

The scrubbed text, a short list of what was replaced, and a separate warning for anything that was already exposed and needs rotating.
